	<footer class="footer">
		<div class="footer_top">
			<div class="container">
				<div class="row">
					<div class="col-12 text-center">
						<h5 style="color:white;" ><?=$mahalleBaslik?></h5>
					</div>
					
					
					
					<div class="col-12 text-center">
						<div class="footer_widget">	
							
							<ul style="list-style-type: none;">
								<li style="display: inline"><a  style="color:black;"  href="<?=SITE?>fotograflar">FOTOĞRAF GALERİ -</a></li>
								<li style="display: inline"><a  style="color:black;"  href="<?=SITE?>videolar">VİDEO GALERİ -</a></li>
								<li style="display: inline"><a  style="color:black;"  href="<?=SITE?>mahalle">MAHALLEMİZ -</a></li>
								<li style="display: inline"><a  style="color:black;"  href="<?=SITE?>muhtarlar">MUHTARIMIZ -</a></li>
								<li style="display: inline"><a  style="color:black;"  href="<?=SITE?>azalar">AZALARIMIZ -</a></li>
								<li style="display: inline"><a  style="color:black;"  href="<?=SITE?>yazarlar">YAZARLARIMIZ </a></li>
							</ul>
						</div>
					</div>
					
					<div class="col-12 text-center">
						<div class="footer_widget">
							
							<ul style="list-style-type: none;">
								<li style="display: inline"><a  style="color:black;"  href="<?=SITE?>etkinlikler">ETKİNLİKLER -</a></li>
								<li style="display: inline"><a  style="color:black;"  href="<?=SITE?>haberler"> HABERLER -</a></li>
								<li style="display: inline"><a  style="color:black;"  href="<?=SITE?>koseyazilari"> KÖŞE YAZILARI -</a></li>
								<li style="display: inline"><a  style="color:black;"  href="<?=SITE?>azalar"> MUHTARLIK İŞLEMLERİ -</a></li>
								<li style="display: inline"><a  style="color:black;"  href="<?=SITE?>vefatedenler"> VEFAT EDENLER -</a></li>
								<li style="display: inline"><a  style="color:black;"  href="<?=SITE?>iletisim"> İLETİŞİM</a></li>
							</ul>
						</div>
					</div>
					
					<div class="col-12 text-center">
						<div class="socail_links">
							<div class="socail_links">
							<ul style="list-style-type: none;">
								<li><a href="<?=$hizmetyeriFacebook?>"> <i class="ti-facebook"></i></a></li>
								<li><a href="<?=$hizmetyeriYoutube?>"> <i class="fa fa-youtube"></i></a></li>
								<li><a href="<?=$hizmetyeriTwitter?>"> <i class="fa fa-twitter"></i></a></li>
								<li><a href="<?=$hizmetyeriInstagram?>"> <i class="fa fa-instagram"></i></a></li>
								<li><a href="<?=$hizmetyeriLinkedin?>"> <i class="fa fa-linkedin"></i></a></li>
							</ul>
						</div>
						</div>
						
					</div>
					
				</div>
			</div>
		</div>	
		
		<div class="copy-right_text">
            <div class="container">
                <div class="footer_border"></div>
                <div class="row">
                    <div class="col-xl-12">
                        <p class="copy_right text-center" style="color:white" >
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> Tüm Hakları Saklıdır.| <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://www.medianostalgie.com/" target="_blank">Media Nostalgie</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        </p>
                    </div>
                </div>
            </div>
        </div>
		
	</footer>