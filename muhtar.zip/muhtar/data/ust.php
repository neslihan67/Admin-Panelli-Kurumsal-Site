    

		
	<!-- header-start -->
    <header>
		
        <div class="header-area ">
			<div style="height:28px; background-color:#1e90ff;" class="container-fluid">
				
						  <h6 style="float:right; color:black; padding:5px;" >TEL:<?=$hizmetyeriTelefon?></h6>
				
				
			</div>
		
            <div id="sticky-header" class="main-header-area">
                <div class="container-fluid ">
                    <div class="header_bottom_border">
                        <div class="row align-items-center">
                            <div class="col-xl-3 col-lg-2">
                                <div class="logo">
                                    <a href="<?=SITE?>">
                                        <img  style="height:75px; width:auto;" src="<?=SITE?>admin/mediaNotalgieLOGO/log.png" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-7">
                                <div class="main-menu  d-none d-lg-block">
                                    <nav>
                                        <ul id="navigation">
                                            <li><a  style="color:black;" href="<?=SITE?>">Anasayfa</a></li>
											  <li><a style="color:black;" href="#">Kurumsal <i class="ti-angle-down"></i></a>
                                                <ul class="submenu">
                                                   
                                                   		<li><a  style="color:black;"  href="<?=SITE?>mahalle">Mahallemiz</a></li>
                                                    <li><a  style="color:black;"  href="<?=SITE?>muhtarlar">Muhtarımız</a></li>
											
													 <li><a  style="color:black;"  href="<?=SITE?>azalar">Azalarımız</a></li>
													  <li><a  style="color:black;"  href="<?=SITE?>yazarlar">Yazarlarımız</a></li>
													  <li><a  style="color:black;"  href="<?=SITE?>islemler">Muhtarlık İşlemleri</a></li>
													   <li><a style="color:black;" href="<?=SITE?>vefatedenler">Vefat Edenler</a></li>
													   <li><a  style="color:black;"  href="<?=SITE?>fotograflar">Fotoğraf Galeri</a></li>
													    <li><a  style="color:black;"  href="<?=SITE?>videolar">Video Galeri</a></li>
													
                                                </ul>
                                            </li>
                                            <li><a style="color:black;" href="<?=SITE?>etkinlikler">Etkinlikler</a></li>
                                          
                                            <li><a  style="color:black;" href="<?=SITE?>haberler">Haberler</a></li>
                                            <li><a  style="color:black;" href="<?=SITE?>koseyazilari">Köşe Yazılarımız</a>
                                               
                                            </li>
                                            <li><a  style="color:black;" href="<?=SITE?>iletisim">İletişim</a></li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 d-none d-lg-block">
                                <div class="Appointment">
                                    <div class="book_btn d-none d-lg-block">
                                        <a href="<?=SITE?>iletisim">Muhtarlığa Ulaşın.</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="mobile_menu d-block d-lg-none"></div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </header>
    <!-- header-end -->