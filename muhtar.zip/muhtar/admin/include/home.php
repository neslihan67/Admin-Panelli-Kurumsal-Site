
  <div class="content-wrapper">

    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">ilgili sayfa adi</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Anasayfa</a></li>
              <li class="breadcrumb-item active">ilgili sayfa adi</li>
            </ol>
				
          </div>
		  
        </div>
		
      </div>
    </div>
	
 <div class="col-md-9">
	    
	
	<?php
	if (!empty($_POST['baslik']))
	{
		if(isset($_POST["submit"]))
		{
	
			$allow=array('pdf');
			
			$temp=explode(".", $_FILES['pdf_file']['name']);
			
			$extension=end($temp);
			
			$upload_file=$_FILES['pdf_file']['name'];
		
			move_uploaded_file($_FILES['pdf_file']['tmp_name'], "admin/uploads".$_FILES['pdf_file']['name']);
			
			
			$baslik=$DB->Filter($_POST['baslik']);
			$ekle=$DB->SorguCalistir("INSERT INTO pdf_dosyalari ","SET Baslik=?,pdf_file=?",array($baslik,$upload_file));
			
		if($ekle!=false)
		{
			?>
			<div class="col-6">
				<div class="alert alert-success">PDF DOSYA EKLEME İŞLEMİ TAMAMLANDI</div>
			</div>
			
			<?php
		}
		}
		else
		{
			?>
			<div class="col-6">
				<div class="alert alert-danger">Dosya yüklemelisiniz</div>
			</div>
			
			<?php
		}
	}


	?>
	    <div class="card card-success">
            <div class="card-header">
                <h3 class="card-title">KAYIT FORMU</h3>
            </div>
	        <form action="#" method="post" enctype="multipart/form-data">
		 
                <div class="card-body">
                       
                
                    <div class="form-group">
                        <label>PDF adı giriniz</label> 
                        <input type="text" class="form-control" style="border-color:#f0dc82;" name="baslik" required="required" placeholder="PDF Adı Giriniz ...">
				    </div>
               
				
				
               
                    <div class="form-group">
                        <label>PDF</label> 
				        <input type="file" class="form-control" style="border-color:#f0dc82;" name="pdf_file" required="required" placeholder="PDF Dosyası Seçiniz">
                    </div>
				
             
			 
		
             
			   
			        <div class="col-md-10">
                        <div class="form-group">
                           <button type="submit" name="submit" style="width:100%;"class="btn btn-block btn-primary btn-lg">Kaydet</button>
				        </div>
			        </div>
			   
			  
			
		        </div> 
	        </form>
    	</div>
          
	</div>	 
  </div>